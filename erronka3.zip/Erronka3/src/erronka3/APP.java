package erronka3;

import javax.swing.*;
import java.awt.*;

public class APP extends JFrame {

    private TaulaPanela taulaPanela;               // Panel para mostrar las tablas
    private TaulaKontrolatzailea kontrolatzailea;  // Controlador de las tablas
    private String mota; // Loginetik jasotako erabiltzaile mota (Tipo de usuario)

    public APP(String mota) {
        this.mota = mota;
        setTitle("Datu-base kudeaketa");   // Título de la ventana
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Configura que la aplicación cierre al cerrar la ventana
        setSize(850, 500); // Tamaño de la ventana
        setLocationRelativeTo(null); // Configura la ventana para que se muestre en el centro de la pantalla

        // Panel principal donde se agregan los componentes
        JPanel edukia = new JPanel(new BorderLayout());
        setContentPane(edukia);

        // Inicializar el controlador de la tabla
        kontrolatzailea = new TaulaKontrolatzailea();

        // Crear el menú lateral y asignar las acciones correspondientes
        MenuPanela menuPanela = new MenuPanela(mota, taulaIzena -> kontrolatzailea.kargatuTaula(taulaIzena, taulaPanela));
        menuPanela.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Añadir margen al menú
        edukia.add(menuPanela, BorderLayout.WEST); // Añadir el menú lateral a la ventana

        // Inicializar el panel de las tablas (para mostrar las tablas cargadas)
        taulaPanela = new TaulaPanela();   // Asegúrate de inicializar esta clase correctamente
        edukia.add(taulaPanela, BorderLayout.CENTER);  // Añadir el panel central de tablas
    }
}
