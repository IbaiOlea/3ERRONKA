package erronka3;

import java.awt.*;
import javax.swing.*;

public class MenuPanela extends JPanel {

    private static final long serialVersionUID = 1L;

    public MenuPanela(String langileMota) {
        setLayout(new BorderLayout());
        
        // Menú goiburua
        JPanel menuPanel = new JPanel();
        menuPanel.setBackground(new Color(255, 165, 0)); // Naranja kolorea
        JLabel menuLabel = new JLabel("Aplikazioaren Menua");
        menuLabel.setFont(new Font("Arial", Font.BOLD, 20));
        menuLabel.setForeground(Color.BLACK); // Letraren kolorea beltza
        menuPanel.add(menuLabel);

        // Menuaren aukerak (botoiak)
        JPanel botoiPanel = new JPanel();
        botoiPanel.setLayout(new GridLayout(4, 1, 10, 10)); // 4 lerro, 1 zutabe
        botoiPanel.setOpaque(false); // Ez ikusi atzean dagoen kolorea

        // Aplikazioaren botoiak, erabiltzaile mota edo rolaren arabera
        if ("Administratzailea".equals(langileMota)) {
            botoiPanel.add(createButton("Kudeatu Langileak"));
            botoiPanel.add(createButton("Ikusi Erabiltzaileen Datuak"));
            botoiPanel.add(createButton("Aldatu Configurazioa"));
        } else if ("Langilea".equals(langileMota)) {
            botoiPanel.add(createButton("Ikusi Nire Datuak"));
            botoiPanel.add(createButton("Aldatu Nire Pasahitza"));
        }

        // Menuaren panel nagusia
        add(menuPanel, BorderLayout.NORTH);
        add(botoiPanel, BorderLayout.CENTER);
    }

    // Botoia sortzen duen laguntza funtzioa
    private JButton createButton(String label) {
        JButton button = new JButton(label);
        button.setBackground(new Color(0, 102, 204)); // Kolore urdina
        button.setForeground(Color.WHITE); // Testu kolorea zuria
        button.setFont(new Font("Arial", Font.BOLD, 14));
        return button;
    }
}