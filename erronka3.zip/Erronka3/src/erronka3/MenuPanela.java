package erronka3;

import javax.swing.*;
import java.awt.*;
import java.util.function.Consumer;

public class MenuPanela extends JPanel {

    public MenuPanela(String mota, Consumer<String> taulaAukeratuCallback) {
        setLayout(new GridLayout(8, 1, 10, 10));
        setBackground(new Color(255, 165, 0)); //Atzealdeko kolorea naranja

        // Erregstratu den erabiltzailea "Administratzailea" bada "langileak" taula kudeatu ahal izango du
        if (mota.equals("Administratzailea")) {
            JButton btnLangileak = new JButton("Langileak");
            btnLangileak.setBackground(new Color(200, 200, 200));
            btnLangileak.setForeground(Color.WHITE);
            btnLangileak.addActionListener(e -> taulaAukeratuCallback.accept("langileak"));
            add(btnLangileak);
        }

     // "produktuak" taula kargatzen duen botoiaren konfigurazioa
        JButton btnProduktuak = new JButton("Produktuak");
        btnProduktuak.setBackground(new Color(200, 200, 200));
        btnProduktuak.setForeground(Color.WHITE);
        btnProduktuak.addActionListener(e -> taulaAukeratuCallback.accept("produktuak"));
        add(btnProduktuak);

     // "hornitzaileak" taula kargatzen duen botoiaren konfigurazioa
        JButton btnEmailea = new JButton("Emailea");
        btnEmailea.setBackground(new Color(200, 200, 200));
        btnEmailea.setForeground(Color.WHITE);
        btnEmailea.addActionListener(e -> taulaAukeratuCallback.accept("hornitzaileak"));
        add(btnEmailea);

     // "erabiltzaileak" taula kargatzen duen botoiaren konfigurazioa
        JButton btnErabiltzaileak = new JButton("Erabiltzaileak");
        btnErabiltzaileak.setBackground(new Color(200, 200, 200));
        btnErabiltzaileak.setForeground(Color.WHITE);
        btnErabiltzaileak.addActionListener(e -> taulaAukeratuCallback.accept("erabiltzaileak"));
        add(btnErabiltzaileak);

        // "eskaerak" taula kargatzen duen botoiaren konfigurazioa
        JButton btnFakturak = new JButton("Fakturak"); // ✅
        btnFakturak.setBackground(new Color(200, 200, 200));
        btnFakturak.setForeground(Color.WHITE);
        btnFakturak.addActionListener(e -> taulaAukeratuCallback.accept("Fakturak"));
        add(btnFakturak);

        // APP-a ixteko botoiaren konfigurazioa
        JButton btnIrten = new JButton("Irten");
        btnIrten.setBackground(Color.RED);
        btnIrten.setForeground(Color.WHITE);
        btnIrten.addActionListener(e -> System.exit(0));
        add(btnIrten);
    }
}
