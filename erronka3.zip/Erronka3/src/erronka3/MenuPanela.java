package erronka3;

import java.awt.*;
import javax.swing.*;
import java.util.function.Consumer; // Para usar Consumer
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MenuPanela extends JPanel {

    private static final long serialVersionUID = 1L;

    public MenuPanela(String langileMota, Consumer<String> botonAccion) {
        setLayout(new BorderLayout());
        
        // Menú goiburua
        JPanel menuPanel = new JPanel();
        menuPanel.setBackground(new Color(255, 165, 0)); // Naranja kolorea
        JLabel menuLabel = new JLabel("Aplikazioaren Menua");
        menuLabel.setFont(new Font("Arial", Font.BOLD, 20));
        menuLabel.setForeground(Color.BLACK); // Letraren kolorea beltza
        menuPanel.add(menuLabel);

        // Menuaren aukerak (botoiak)
        JPanel botoiPanel = new JPanel();
        botoiPanel.setLayout(new GridLayout(5, 1, 10, 10)); // 5 lerro, 1 zutabe
        botoiPanel.setOpaque(false); // Ez ikusi atzean dagoen kolorea

        // Aplikazioaren botoiak, erabiltzaile mota edo rolaren arabera
        if ("Fisioterapeuta".equals(langileMota)) {
            botoiPanel.add(createButton("Langileak Kudeatu", botonAccion));
            botoiPanel.add(createButton("Ikusi Erabiltzaileen Datuak", botonAccion));
            botoiPanel.add(createButton("Aldatu Configurazioa", botonAccion));
        } else if ("Langilea".equals(langileMota)) {
            botoiPanel.add(createButton("Ikusi Nire Datuak", botonAccion));
            botoiPanel.add(createButton("Aldatu Nire Pasahitza", botonAccion));
        }

        // Añadir botón para la calculadora de IMC
        JButton imcButton = new JButton("IMC Kalkulagailua");
        imcButton.setBackground(new Color(0, 102, 204)); // Kolore urdina
        imcButton.setForeground(Color.WHITE); // Testu kolorea zuria
        imcButton.setFont(new Font("Arial", Font.BOLD, 14));
        imcButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Cambiar el contenido del panel principal a la calculadora de IMC
                APP.getMainPanel().removeAll();
                APP.getMainPanel().add(new ImcKalkulagailuPanela(), BorderLayout.CENTER);
                APP.getMainPanel().revalidate();
                APP.getMainPanel().repaint();
            }
        });
        botoiPanel.add(imcButton);

        // Menuaren panel nagusia
        add(menuPanel, BorderLayout.NORTH);
        add(botoiPanel, BorderLayout.CENTER);
    }

    // Botoia sortzen duen laguntza funtzioa
    private JButton createButton(String label, Consumer<String> botonAccion) {
        JButton button = new JButton(label);
        button.setBackground(new Color(0, 102, 204)); // Kolore urdina
        button.setForeground(Color.WHITE); // Testu kolorea zuria
        button.setFont(new Font("Arial", Font.BOLD, 14));
        
        // Agregar la acción al botón
        button.addActionListener(e -> botonAccion.accept(label)); // Pasamos el nombre del botón a la acción

        return button;
    }
}