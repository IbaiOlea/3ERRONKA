package erronka3;

import javax.swing.*;
import java.awt.*;

public class TaulaPanela extends JPanel {

    private JTable taula; // Para almacenar la tabla actual

    public TaulaPanela() {
        // Establecemos un BorderLayout para gestionar las posiciones de los componentes
        setLayout(new BorderLayout());
    }

    // Este método establece la JTable proporcionada en el centro del panel
    public void ezarriTaula(JTable taula) {
        // Si ya hay una tabla en el panel, la eliminamos
        if (this.taula != null) {
            removeAll();
        }

        this.taula = taula; // Actualizamos la referencia a la nueva tabla

        // Creamos un JScrollPane para que la tabla sea desplazable y lo agregamos al panel
        JScrollPane scrollPane = new JScrollPane(taula);
        add(scrollPane, BorderLayout.CENTER); // Añadimos el JScrollPane en el centro
        revalidate(); // Revalidamos el layout para actualizar el panel
        repaint();    // Forzamos una actualización visual
    }

    // Este método agrega un panel de operaciones (con botones) en la parte inferior del panel
    public void gehituOperazioPanela(JPanel operazioPanela) {
        if (operazioPanela != null) {
            add(operazioPanela, BorderLayout.SOUTH); // Añadimos el panel de operaciones al sur
        }
        revalidate(); // Revalidamos el layout para reflejar los cambios
        repaint();    // Forzamos una actualización visual
    }

    // Método para obtener la JTable actual
    public JTable lortuTaula() {
        return taula;
    }
}
