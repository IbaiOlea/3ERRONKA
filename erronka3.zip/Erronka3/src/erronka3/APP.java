package erronka3;

import javax.swing.*;
import java.awt.*;

public class APP extends JFrame {

    private static final long serialVersionUID = 1L;
    private static JPanel mainPanel;

    public APP(String erabiltzailea, String lanpostua) {
        setTitle("Aplikazioa Nagusia");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        mainPanel = new JPanel(new BorderLayout());
        setContentPane(mainPanel);

        // Añadir el panel del menú
        MenuPanela menuPanela = new MenuPanela(lanpostua, this::handleButtonAction);
        mainPanel.add(menuPanela, BorderLayout.WEST);

        // Panel inicial (puede ser un panel de bienvenida o similar)
        JPanel initialPanel = new JPanel();
        initialPanel.add(new JLabel("Ongi etorri, " + erabiltzailea + " aplikaziora"));
        mainPanel.add(initialPanel, BorderLayout.CENTER);
    }

    public static JPanel getMainPanel() {
        return mainPanel;
    }

    private void handleButtonAction(String action) {
        switch (action) {
            case "Langileak Kudeatu":
                // Mostrar el panel de gestión de empleados
                mainPanel.removeAll();
                mainPanel.add(new LangileakKudeatuPanela(), BorderLayout.CENTER);
                mainPanel.revalidate();
                mainPanel.repaint();
                break;
            case "Ikusi Erabiltzaileen Datuak":
                // Lógica para ver datos de usuarios
                break;
            case "Aldatu Configurazioa":
                // Lógica para cambiar configuración
                break;
            case "Ikusi Nire Datuak":
                // Lógica para ver mis datos
                break;
            case "Aldatu Nire Pasahitza":
                // Lógica para cambiar mi contraseña
                break;
            default:
                break;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new Login().setVisible(true);
        });
    }
}