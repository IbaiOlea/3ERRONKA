package erronka3;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;

import java.awt.Color;
import java.io.File;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

// PDF sortzeko klasea
public class PdfSortzailea {

	public static boolean generatePDF(String ErabiltzaileId, String Erosketa_data, File outputFile) {
	    try (Connection conn = DBKonexioa.lortuKonexioa()) {
	        // 1. Obtener datos del usuario
	        String erabiltzaileQuery = "SELECT Izena, Abizena FROM erabiltzaileak WHERE ID = ?";
	        String izena = "", abizena = "";
	        
	        try (PreparedStatement pstmt = conn.prepareStatement(erabiltzaileQuery)) {
	            pstmt.setString(1, ErabiltzaileId);
	            try (ResultSet rs = pstmt.executeQuery()) {
	                if (rs.next()) {
	                    izena = rs.getString("Izena");
	                    abizena = rs.getString("Abizena");
	                }
	            }
	        }

	        // 2. Obtener detalles de la factura
	        String fakturaQuery = "SELECT p.Izena, f.Kantitatea, f.Prezioa " +
	                              "FROM fakturak f " +
	                              "JOIN produktuak p ON f.ProduktuaID = p.ID " +
	                              "WHERE f.ErabiltzaileID = ? AND f.Erosketa_data = ?";
	        
	        List<String[]> items = new ArrayList<>();
	        double guztira = 0.0;
	        
	        try (PreparedStatement pstmt = conn.prepareStatement(fakturaQuery)) {
	            pstmt.setString(1, ErabiltzaileId);
	            pstmt.setString(2, Erosketa_data);
	            try (ResultSet rs = pstmt.executeQuery()) {
	                while (rs.next()) {
	                    String produktua = rs.getString("Izena");
	                    int kantitatea = rs.getInt("Kantitatea");
	                    double prezioa = rs.getDouble("Prezioa");
	                    double subtotal = kantitatea * prezioa;
	                    guztira += subtotal;
	                    
	                    items.add(new String[]{
	                        produktua,
	                        String.valueOf(kantitatea),
	                        String.format("%.2f €", prezioa),
	                        String.format("%.2f €", subtotal)
	                    });
	                }
	            }
	        }

	        // 3. Crear PDF
	        try (PDDocument document = new PDDocument()) {
	            PDPage page = new PDPage();
	            document.addPage(page);

	            try (PDPageContentStream contentStream = new PDPageContentStream(document, page)) {
	                contentStream.setFont(PDType1Font.HELVETICA_BOLD, 16);
	                
	                // Cabecera
	                contentStream.beginText();
	                contentStream.newLineAtOffset(50, 750);
	                contentStream.showText("Faktura - SaludNatural");
	                contentStream.endText();
	                
	                try {
                    	PDImageXObject image = PDImageXObject.createFromFile("image/M.S.N_Logo.png", document);
                        float imageWidth = 80;
                        float imageHeight = 80;
                        float imageX = page.getMediaBox().getWidth() - imageWidth - 20;
                        float imageY = 720;
                        contentStream.drawImage(image, imageX, imageY, imageWidth, imageHeight);
                    } catch (Exception imgEx) {
                        System.err.println("No se pudo cargar la imagen: " + imgEx.getMessage());
                    }

	                // Datos cliente
	                contentStream.setFont(PDType1Font.HELVETICA, 12);
	                contentStream.beginText();
	                contentStream.newLineAtOffset(50, 700);
	                contentStream.showText("Cliente: " + izena + " " + abizena);
	                contentStream.newLineAtOffset(0, -20);
	                contentStream.showText("Fecha: " + Erosketa_data);
	                contentStream.newLineAtOffset(0, -40);

	                // Tabla de productos
	                int yPos = 620;
	                contentStream.showText("Producto           Cantidad   Precio   Subtotal");
	                contentStream.newLineAtOffset(0, -30);
	                
	                for (String[] item : items) {
	                    String line = String.format("%-20s %-8s %-10s %s", 
	                        item[0], item[1], item[2], item[3]);
	                    contentStream.showText(line);
	                    contentStream.newLineAtOffset(0, -20);
	                    yPos -= 20;
	                }

	                // Total
	                contentStream.newLineAtOffset(0, -30);
	                contentStream.showText("Total: " + String.format("%.2f €", guztira));
	                contentStream.endText();
	            }

	            document.save(outputFile);
	            JOptionPane.showMessageDialog(null, "Factura generada: " + outputFile.getName());
	            return true;
	        }
	    } catch (Exception ex) {
	        ex.printStackTrace();
	        JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
	        return false;
	    }
	}
}