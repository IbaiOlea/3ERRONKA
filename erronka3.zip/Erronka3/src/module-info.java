module erronka3{
	
	requires java.desktop;
	requires java.sql;
	requires org.apache.fontbox;
	requires org.apache.pdfbox;
	
}