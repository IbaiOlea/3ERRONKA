package erronka3;

public abstract class Langile {
    private int id; // ahora es int, ya que es autoincremental (opcionalmente Integer si puede ser null)
    private String izena;
    private String abizena;
    private String erabiltzailea;
    private String pasahitza;

    // Constructor sin id (porque lo asigna la base de datos)
    public Langile(String izena, String abizena, String erabiltzailea, String pasahitza) {
        this.izena = izena;
        this.abizena = abizena;
        this.erabiltzailea = erabiltzailea;
        this.pasahitza = pasahitza;
    }

    // Setter del ID (solo si hace falta asignarlo desde fuera después de guardarlo en la BD)
    public void setId(int id) {
        this.id = id;
    }

    public int getId() { return id; }
    public String getIzena() { return izena; }
    public String getAbizena() { return abizena; }
    public String getErabiltzailea() { return erabiltzailea; }

    public abstract void lanakEgitu();
}

class Administratzailea extends Langile {
    public Administratzailea(String izena, String abizena, String erabiltzailea, String pasahitza) {
        super(izena, abizena, erabiltzailea, pasahitza);
    }

    @Override
    public void lanakEgitu() {
        System.out.println("Administratzaile " + getIzena() + ": Langileen kudeaketa eta datu-basearen mantentzioa.");
    }
}

class LangileKudeatzailea {
    public static void main(String[] args) {
        Langile[] langileak = {
            new Administratzailea("Ane", "Garcia", "admin", "admin123")
        };

        for (Langile langile : langileak) {
            langile.lanakEgitu();
        }
    }
}