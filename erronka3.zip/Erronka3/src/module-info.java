module erronka3 {
    requires java.desktop;  // Necesario para Swing/AWT
    requires java.sql;      // Necesario para JDBC (base de datos)
    requires org.apache.pdfbox;  // Necesario para PDFBox
    requires org.apache.fontbox;  // Necesario para PDFBox
}