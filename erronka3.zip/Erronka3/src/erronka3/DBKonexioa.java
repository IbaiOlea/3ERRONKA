package erronka3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

// Datu basearekin konexioaren konfigurazioa
public class DBKonexioa {
    private static final String URL = "jdbc:mysql://172.16.237.104/erronka3";; // Datu basearen IP eta izena
    private static final String ERABILTZAILEA = "root"; // Datu basearen erabiltzailea
    private static final String PASAHITZA = "5Taldea5"; // Datu basearen pasahitza

    public static Connection lortuKonexioa() throws SQLException {
        return DriverManager.getConnection(URL, ERABILTZAILEA, PASAHITZA); // Datu basearekin konexioa
    }
}