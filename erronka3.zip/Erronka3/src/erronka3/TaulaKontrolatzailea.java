package erronka3;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TaulaKontrolatzailea {

    private JTable taula;
    private final DBEkintzak ekintzak;
    private TaulaPanela taulaPanela;
    private JPanel operazioPanela;

    public TaulaKontrolatzailea() {
        ekintzak = new DBEkintzak();
    }

    private void taulaEguneratu(String taulaIzena) {
        taula = Kontsulta.lortuTaulenDatuak(taulaIzena);
        if (taulaPanela != null) {
            taulaPanela.ezarriTaula(taula);
            if (operazioPanela != null && operazioPanela.getComponentCount() > 0) {
                taulaPanela.gehituOperazioPanela(operazioPanela);
            }
        }
    }

    public void kargatuTaula(String taulaIzena, TaulaPanela taulaPanela) {
        if (taulaIzena == null || taulaPanela == null) {
            throw new IllegalArgumentException("Taula izena eta taula panela ezin dira nul izan");
        }

        this.taulaPanela = taulaPanela;
        taula = Kontsulta.lortuTaulenDatuak(taulaIzena);
        taulaPanela.ezarriTaula(taula);

        operazioPanela = new JPanel(new FlowLayout());
        operazioPanela.setBackground(new Color(240, 240, 240));

        switch (taulaIzena.toLowerCase()) {
            case "erabiltzaileak":
            case "hornitzaileak":
                gehituEguneratuEzabatuBotoiak(taulaIzena);
                break;
            case "fakturak":
                JButton btnPDFDeskargatu = sortuBotoia("PDF Deskargatu", e -> pdfDeskargatu());
                operazioPanela.add(btnPDFDeskargatu);
                break;
            case "langileak":
            case "produktuak":
                gehituEguneratuEzabatuBotoiak(taulaIzena);
                JButton btnGehitu = sortuBotoia("Erregistroa Gehitu", e -> gehituErregistroa(taulaIzena));
                operazioPanela.add(btnGehitu);
                break;
            default:
                break;
        }

        if (operazioPanela.getComponentCount() > 0) {
            taulaPanela.gehituOperazioPanela(operazioPanela);
        }
    }

    private void gehituEguneratuEzabatuBotoiak(String taulaIzena) {
        JButton btnEguneratu = sortuBotoia("Erregistroa Eguneratu", e -> eguneratuErregistroa(taulaIzena));
        JButton btnEzabatu = sortuBotoia("Erregistroa Ezabatu", e -> ezabatuErregistroa(taulaIzena));
        operazioPanela.add(btnEguneratu);
        operazioPanela.add(btnEzabatu);
    }

    private JButton sortuBotoia(String testua, java.awt.event.ActionListener ekintza) {
        JButton botoia = new JButton(testua);
        botoia.setBackground(new Color(200, 200, 200));
        botoia.setForeground(Color.BLACK);
        botoia.addActionListener(ekintza);
        return botoia;
    }

    private void pdfDeskargatu() {
        JPanel panel = new JPanel(new GridLayout(2, 2, 5, 5));
        JLabel lblUser = new JLabel("ErabiltzaileID:");
        JComboBox<String> cmbUser = new JComboBox<>();
        JLabel lblDate = new JLabel("Erosketa_Data:");
        JComboBox<String> cmbDate = new JComboBox<>();

        try (Connection conn = DBKonexioa.lortuKonexioa();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT DISTINCT ErabiltzaileID FROM Fakturak")) {
            
            while (rs.next()) {
                cmbUser.addItem(rs.getString("ErabiltzaileID"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Errorea erabiltzaileak kargatzerakoan: " + ex.getMessage(), "Errorea", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (cmbUser.getItemCount() == 0) {
            JOptionPane.showMessageDialog(null, "Ez daude fakturak erakusteko", "Informazioa", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        cmbUser.addActionListener(e -> kargatuErosketaDatak(cmbUser, cmbDate));

        panel.add(lblUser);
        panel.add(cmbUser);
        panel.add(lblDate);
        panel.add(cmbDate);

        int aukera = JOptionPane.showConfirmDialog(null, panel, "Eskaera aukeraketa", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        
        if (aukera == JOptionPane.OK_OPTION) {
            prozesatuPDFDeskarga(cmbUser, cmbDate);
        }
    }

    private void kargatuErosketaDatak(JComboBox<String> cmbUser, JComboBox<String> cmbDate) {
        cmbDate.removeAllItems();
        String selectedUser = (String) cmbUser.getSelectedItem();
        
        if (selectedUser != null) {
            try (Connection conn = DBKonexioa.lortuKonexioa();
                 PreparedStatement pstmt = conn.prepareStatement(
                         "SELECT DISTINCT Erosketa_Data FROM Fakturak WHERE ErabiltzaileID = ?")) {
                
                pstmt.setString(1, selectedUser);
                try (ResultSet rs = pstmt.executeQuery()) {
                    while (rs.next()) {
                        // Convertir a String si la columna es de tipo DATE
                        Date fecha = rs.getDate("Erosketa_Data");
                        cmbDate.addItem(fecha.toString()); // o usar formato específico
                    }
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Errorea datak kargatzerakoan: " + ex.getMessage(), "Errorea", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void prozesatuPDFDeskarga(JComboBox<String> cmbUser, JComboBox<String> cmbDate) {
        String selectedUser = (String) cmbUser.getSelectedItem();
        String selectedDate = (String) cmbDate.getSelectedItem();

        if (selectedUser == null || selectedDate == null) {
            JOptionPane.showMessageDialog(null, "Erabiltzaile eta Erosketa_Data bat aukeratu behar dituzu!", "Abisua", JOptionPane.WARNING_MESSAGE);
            return;
        }

        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Faktura Sortu");
        int erabAukera = fileChooser.showSaveDialog(null);

        if (erabAukera == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            
            if (!fileToSave.getName().toLowerCase().endsWith(".pdf")) {
                fileToSave = new File(fileToSave.getAbsolutePath() + ".pdf");
            }

            boolean arrakastatsua = PdfSortzailea.generatePDF(selectedUser, selectedDate, fileToSave);

            if (arrakastatsua) {
                JOptionPane.showMessageDialog(null, "PDF-a ongi gorde da: " + fileToSave.getAbsolutePath(), "Arrakasta", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Errorea PDF-a sortzerakoan", "Errorea", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void eguneratuErregistroa(String taulaIzena) {
        if (taula == null || taula.getSelectedRow() == -1) {
            JOptionPane.showMessageDialog(null, "Aukeratu erregistroa eguneratzeko, mesedez.",
                    "Erregistroa eguneratu", JOptionPane.WARNING_MESSAGE);
            return;
        }

        DefaultTableModel modeloa = (DefaultTableModel) taula.getModel();
        int aukeratutakoErrenkada = taula.getSelectedRow();
        String giltzaZutabe = taula.getColumnName(0);

        // Crear panel para los campos
        JPanel sarreraPanela = new JPanel(new GridLayout(modeloa.getColumnCount(), 2, 5, 5));
        List<String> eguneratuZutabeak = new ArrayList<>();
        List<JTextField> eremuak = new ArrayList<>();

        // Incluir TODOS los campos, incluido el ID
        for (int i = 0; i < modeloa.getColumnCount(); i++) {
            String zutabeIzena = taula.getColumnName(i);
            Object unekoBalioa = taula.getValueAt(aukeratutakoErrenkada, i);
            
            sarreraPanela.add(new JLabel(zutabeIzena + ":"));
            JTextField eremua = new JTextField(unekoBalioa != null ? unekoBalioa.toString() : "");
            
            // Hacer que el campo ID no sea editable si lo prefieres
            if (i == 0 && (taulaIzena.equalsIgnoreCase("langileak") || 
                          taulaIzena.equalsIgnoreCase("produktuak"))) {
                eremua.setEditable(false);
                eremua.setBackground(Color.LIGHT_GRAY);
            }
            
            eremuak.add(eremua);
            sarreraPanela.add(eremua);
            eguneratuZutabeak.add(zutabeIzena);
        }

        int emaitza = JOptionPane.showConfirmDialog(null, sarreraPanela,
                "Erregistroa eguneratu (giltza: " + taula.getValueAt(aukeratutakoErrenkada, 0) + ")",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (emaitza == JOptionPane.OK_OPTION) {
            List<String> eguneratuBalioak = new ArrayList<>();
            for (JTextField eremua : eremuak) {
                eguneratuBalioak.add(eremua.getText().trim());
            }

            // Obtener el valor original del ID para la condición WHERE
            String giltzaBalio = taula.getValueAt(aukeratutakoErrenkada, 0).toString();
            
            boolean arrakastatsua = ekintzak.erregistroaEguneratu(
                    taulaIzena, 
                    giltzaZutabe, 
                    giltzaBalio,
                    eguneratuZutabeak.toArray(new String[0]),
                    eguneratuBalioak.toArray(new String[0]));

            JOptionPane.showMessageDialog(null,
                    arrakastatsua ? "Erregistroa eguneratuta." : "Akatsa erregistroa eguneratzean.",
                    arrakastatsua ? "Arrakasta" : "Errorea",
                    arrakastatsua ? JOptionPane.INFORMATION_MESSAGE : JOptionPane.ERROR_MESSAGE);

            taulaEguneratu(taulaIzena);
        }
    }

    
    private void ezabatuErregistroa(String taulaIzena) {
        if (taula == null || taula.getSelectedRow() == -1) {
            JOptionPane.showMessageDialog(null, "Aukeratu ezabatzeko erregistroa, mesedez.",
                    "Ezabatu", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String giltzaZutabe = taula.getColumnName(0);
        Object giltzaBalio = taula.getValueAt(taula.getSelectedRow(), 0);

        int baieztapen = JOptionPane.showConfirmDialog(null,
                giltzaZutabe + " " + giltzaBalio + " duen erregistro ezabatu nahi duzula seguru zaude?",
                "Ziurtagarria", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        
        if (baieztapen != JOptionPane.YES_OPTION) {
            return;
        }

        boolean arrakastatsua = ekintzak.erregistroaEzabatu(taulaIzena, giltzaZutabe, giltzaBalio.toString());
        
        JOptionPane.showMessageDialog(null, 
            arrakastatsua ? "Erregistroa ezabatuta." : "Akatsa erregistroa ezabatzean.",
            arrakastatsua ? "Arrakasta" : "Errorea",
            arrakastatsua ? JOptionPane.INFORMATION_MESSAGE : JOptionPane.ERROR_MESSAGE);
        
        taulaEguneratu(taulaIzena);
    }

    private void gehituErregistroa(String taulaIzena) {
        DefaultTableModel modeloa = (DefaultTableModel) taula.getModel();
        int zutabeKopurua = modeloa.getColumnCount();
        
        JPanel sarreraPanela = new JPanel(new GridLayout(zutabeKopurua, 2, 5, 5));
        List<JTextField> eremuak = new ArrayList<>();
        
        // Incluir TODOS los campos, incluido el ID (no autoincremental)
        for (int i = 0; i < zutabeKopurua; i++) {
            String zutabeIzena = taula.getColumnName(i);
            sarreraPanela.add(new JLabel(zutabeIzena + ":"));
            JTextField eremua = new JTextField();
            eremuak.add(eremua);
            sarreraPanela.add(eremua);
        }
        
        int emaitza = JOptionPane.showConfirmDialog(
            null, 
            sarreraPanela, 
            "Erregistro berria gehitu - " + taulaIzena, 
            JOptionPane.OK_CANCEL_OPTION, 
            JOptionPane.PLAIN_MESSAGE
        );
        
        if (emaitza == JOptionPane.OK_OPTION) {
            List<String> zutabeIzenak = new ArrayList<>();
            List<String> balioak = new ArrayList<>();
            
            for (int i = 0; i < zutabeKopurua; i++) {
                zutabeIzenak.add(taula.getColumnName(i));
                balioak.add(eremuak.get(i).getText().trim());
            }
            
            boolean arrakastatsua = ekintzak.erregistroaGehitu(
                taulaIzena,
                zutabeIzenak.toArray(new String[0]),
                balioak.toArray(new String[0])
            );
            
            JOptionPane.showMessageDialog(
                null, 
                arrakastatsua ? "Erregistroa ondo gehitu da." : "Errorea erregistroa gehitzean.",
                arrakastatsua ? "Arrakasta" : "Errorea",
                arrakastatsua ? JOptionPane.INFORMATION_MESSAGE : JOptionPane.ERROR_MESSAGE
            );
            
            taulaEguneratu(taulaIzena);
        }
    }
}