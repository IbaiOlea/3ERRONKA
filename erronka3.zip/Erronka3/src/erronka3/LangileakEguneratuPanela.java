package erronka3;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class LangileakEguneratuPanela extends JPanel {

    private static final long serialVersionUID = 1L;
    private JTextField txtId, txtIzena, txtAbizena, txtUsuarioa, txtPostaElektronikoa, txtLanpostua;

    public LangileakEguneratuPanela() {
        setLayout(new BorderLayout());

        // Panel de cabecera
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(255, 165, 0)); // Naranja kolorea
        JLabel headerLabel = new JLabel("Langileak Eguneratu");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 20));
        headerLabel.setForeground(Color.BLACK); // Letraren kolorea beltza
        headerPanel.add(headerLabel);

        // Panel de formulario
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(7, 2, 10, 10));

        formPanel.add(new JLabel("Langilearen ID:"));
        txtId = new JTextField(15);
        formPanel.add(txtId);

        formPanel.add(new JLabel("Izena:"));
        txtIzena = new JTextField(15);
        formPanel.add(txtIzena);

        formPanel.add(new JLabel("Abizena:"));
        txtAbizena = new JTextField(15);
        formPanel.add(txtAbizena);

        formPanel.add(new JLabel("Usuarioa:"));
        txtUsuarioa = new JTextField(15);
        formPanel.add(txtUsuarioa);

        formPanel.add(new JLabel("Posta Elektronikoa:"));
        txtPostaElektronikoa = new JTextField(15);
        formPanel.add(txtPostaElektronikoa);

        formPanel.add(new JLabel("Lanpostua:"));
        txtLanpostua = new JTextField(15);
        formPanel.add(txtLanpostua);

        JButton btnEguneratu = new JButton("Eguneratu");
        btnEguneratu.setBackground(new Color(0, 102, 204)); // Kolore urdina
        btnEguneratu.setForeground(Color.WHITE); // Testu kolorea zuria
        btnEguneratu.setFont(new Font("Arial", Font.BOLD, 14));
        btnEguneratu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eguneratuLangilea();
            }
        });

        formPanel.add(new JLabel());
        formPanel.add(btnEguneratu);

        // Añadir paneles al panel principal
        add(headerPanel, BorderLayout.NORTH);
        add(formPanel, BorderLayout.CENTER);
    }

    private void eguneratuLangilea() {
        String id = txtId.getText().trim();
        String izena = txtIzena.getText().trim();
        String abizena = txtAbizena.getText().trim();
        String usuarioa = txtUsuarioa.getText().trim();
        String postaElektronikoa = txtPostaElektronikoa.getText().trim();
        String lanpostua = txtLanpostua.getText().trim();

        if (id.isEmpty() || izena.isEmpty() || abizena.isEmpty() || usuarioa.isEmpty() || postaElektronikoa.isEmpty() || lanpostua.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Mesedez, bete eremu guztiak.", "Errorea", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String sql = "UPDATE langileak SET Izena = ?, Abizena = ?, Usuarioa = ?, Posta_elektronikoa = ?, Lanpostua = ? WHERE ID = ?";

        try (Connection konexioa = DBKonexioa.lortuKonexioa();
             PreparedStatement pstmt = konexioa.prepareStatement(sql)) {

            pstmt.setString(1, izena);
            pstmt.setString(2, abizena);
            pstmt.setString(3, usuarioa);
            pstmt.setString(4, postaElektronikoa);
            pstmt.setString(5, lanpostua);
            pstmt.setString(6, id);

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                JOptionPane.showMessageDialog(this, "Langilea eguneratu da.", "Arrakasta", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Langilearen IDa ez da aurkitu.", "Errorea", JOptionPane.ERROR_MESSAGE);
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Errorea gertatu da langilea eguneratzean.", "Errorea", JOptionPane.ERROR_MESSAGE);
        }
    }
}