package erronka3;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LangileakKudeatuPanela extends JPanel {

    private static final long serialVersionUID = 1L;

    public LangileakKudeatuPanela() {
        setLayout(new BorderLayout());

        // Panel de cabecera
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(255, 165, 0)); // Naranja kolorea
        JLabel headerLabel = new JLabel("Langileak Kudeatu");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 20));
        headerLabel.setForeground(Color.BLACK); // Letraren kolorea beltza
        headerPanel.add(headerLabel);

        // Panel de botones
        JPanel botoiPanel = new JPanel();
        botoiPanel.setLayout(new GridLayout(3, 1, 10, 10)); // 3 lerro, 1 zutabe

        // Botón para borrar langileak
        JButton btnEzabatu = new JButton("Langileak Ezabatu");
        btnEzabatu.setBackground(new Color(0, 102, 204)); // Kolore urdina
        btnEzabatu.setForeground(Color.WHITE); // Testu kolorea zuria
        btnEzabatu.setFont(new Font("Arial", Font.BOLD, 14));
        btnEzabatu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Mostrar panel de borrado
                APP.getMainPanel().removeAll();
                APP.getMainPanel().add(new LangileakEzabatuPanela(), BorderLayout.CENTER);
                APP.getMainPanel().revalidate();
                APP.getMainPanel().repaint();
            }
        });
        botoiPanel.add(btnEzabatu);

        // Botón para actualizar langileak
        JButton btnEguneratu = new JButton("Langileak Eguneratu");
        btnEguneratu.setBackground(new Color(0, 102, 204)); // Kolore urdina
        btnEguneratu.setForeground(Color.WHITE); // Testu kolorea zuria
        btnEguneratu.setFont(new Font("Arial", Font.BOLD, 14));
        btnEguneratu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Mostrar panel de actualización
                APP.getMainPanel().removeAll();
                APP.getMainPanel().add(new LangileakEguneratuPanela(), BorderLayout.CENTER);
                APP.getMainPanel().revalidate();
                APP.getMainPanel().repaint();
            }
        });
        botoiPanel.add(btnEguneratu);

        // Botón para hacer consultas
        JButton btnKontsultatu = new JButton("Langileak Kontsultatu");
        btnKontsultatu.setBackground(new Color(0, 102, 204)); // Kolore urdina
        btnKontsultatu.setForeground(Color.WHITE); // Testu kolorea zuria
        btnKontsultatu.setFont(new Font("Arial", Font.BOLD, 14));
        btnKontsultatu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Mostrar panel de consultas
                APP.getMainPanel().removeAll();
                APP.getMainPanel().add(new LangileakKontsultatuPanela(), BorderLayout.CENTER);
                APP.getMainPanel().revalidate();
                APP.getMainPanel().repaint();
            }
        });
        botoiPanel.add(btnKontsultatu);

        // Añadir paneles al panel principal
        add(headerPanel, BorderLayout.NORTH);
        add(botoiPanel, BorderLayout.CENTER);
    }
}