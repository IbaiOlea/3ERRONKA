package erronka3;

import javax.swing.*;
import java.awt.*;

public class APP extends JFrame {
	
	private static final long serialVersionUID = 1L;
    private static JPanel edukia;               // Panel principal
	private TaulaPanela taulaPanela;            // Panel para mostrar las tablas
    private TaulaKontrolatzailea kontrolatzailea;  // Controlador de las tablas
    
    public APP(String mota) {
        setTitle("Datu-base kudeaketa");   // Título de la ventana
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Configura que la aplicación cierre al cerrar la ventana
        setSize(850, 500); // Tamaño de la ventana
        setLocationRelativeTo(null); // Configura la ventana para que se muestre en el centro de la pantalla

        // Panel principal donde se agregan los componentes
        edukia = new JPanel(new BorderLayout());
        setContentPane(edukia);

        // Inicializar el controlador de la tabla
        kontrolatzailea = new TaulaKontrolatzailea();

        // Crear el menú lateral y asignar las acciones correspondientes
        MenuPanela menuPanela = new MenuPanela(mota, taulaIzena -> kontrolatzailea.kargatuTaula(taulaIzena, taulaPanela));
        menuPanela.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Añadir margen al menú
        edukia.add(menuPanela, BorderLayout.WEST); // Añadir el menú lateral a la ventana

        // Inicializar el panel de las tablas (para mostrar las tablas cargadas)
        taulaPanela = new TaulaPanela();   // Asegúrate de inicializar esta clase correctamente
        edukia.add(taulaPanela, BorderLayout.CENTER);  // Añadir el panel central de tablas
    }

    public static JPanel getMainPanel() {
        return edukia;
    }

    public static void main(String[] args) {
        // Mostrar la ventana de inicio de sesión
        SwingUtilities.invokeLater(() -> {
            Login login = new Login();
            login.setVisible(true);
        });
    }

    // Método para iniciar la aplicación principal después del login
    public static void iniciarApp(String mota) {
        SwingUtilities.invokeLater(() -> {
            APP app = new APP(mota);
            app.setVisible(true);
        });
    }
}