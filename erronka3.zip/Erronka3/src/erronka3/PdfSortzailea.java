package erronka3;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

import java.awt.Color;
import java.io.File;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

// PDF sortzeko klasea
public class PdfSortzailea {

    public static boolean generatePDF(String ErabiltzaileId, String Eskaera_data, File outputFile) {
        // Erabiltzailearen datuak
        String izena = "";
        String abizena = "";
        String postaElektronikoa = "";
        double guztira = 0.0;
        int fakturaId = -1;

        // Datu basera konektatu eta informazioa lortu
        try (Connection conn = DBKonexioa.lortuKonexioa()) {

            // 1. Erabiltzailearen datuak lortu
        	String erabiltzaileQuery = "SELECT Izena, Abizena, Posta_elektronikoa FROM erabiltzaileak WHERE ID = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(erabiltzaileQuery)) {
                pstmt.setString(1, ErabiltzaileId);
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        izena = rs.getString("Izena");
                        abizena = rs.getString("Abizena");
                        postaElektronikoa = rs.getString("Posta_elektronikoa");
                    } else {
                        return false; // Erabiltzailea ez bada existitzen
                    }
                }
            }

            // 2. Fakturaren informazioa lortu
            String fakturaQuery = "SELECT ID, Guztira FROM fakturak WHERE Erabiltzaile_ID = ? AND DATE(Eskaera_data) = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(fakturaQuery)) {
                pstmt.setString(1, ErabiltzaileId);
                pstmt.setString(2, Eskaera_data);
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        fakturaId = rs.getInt("ID");
                        guztira = rs.getDouble("Guztira");
                    } else {
                        return false; // Faktura ez bada existitzen
                    }
                }
            }

            // 3. Produktuen informazioa lortu
            List<ProductInfo> productList = new ArrayList<>();
            String produktuakQuery = "SELECT p.Izena, ep.Kantitatea, ep.Subtotal " +
                    "FROM erosketa_produktuak ep " +
                    "JOIN produktuak p ON ep.Produktu_ID = p.ID " +
                    "WHERE ep.Fakturak_ID = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(produktuakQuery)) {
                pstmt.setInt(1, fakturaId);
                try (ResultSet rs = pstmt.executeQuery()) {
                    while (rs.next()) {
                        String produktuaIzena = rs.getString("Izena");
                        int kantitatea = rs.getInt("Kantitatea");
                        double subtotal = rs.getDouble("Subtotal");

                        productList.add(new ProductInfo(produktuaIzena, kantitatea, subtotal));
                    }
                }
            }

            // 4. PDF sortu
            try (PDDocument document = new PDDocument()) {
                PDPage page = new PDPage();
                document.addPage(page);

                PDPageContentStream contentStream = new PDPageContentStream(document, page);
                contentStream.setStrokingColor(Color.BLACK);

                int yPosition = 750; 
                int lineHeight = 20;

                // Faktura izenburua
                int headerHeight = 30;     
                int headerX = 50;           
                int headerWidth = 500;      
                int headerY = yPosition - headerHeight;

                contentStream.setNonStrokingColor(Color.GRAY);
                contentStream.addRect(headerX, headerY, headerWidth, headerHeight);
                contentStream.fill();
                contentStream.setNonStrokingColor(Color.BLACK);

                contentStream.setFont(PDType1Font.HELVETICA_BOLD, 16);
                contentStream.beginText();
                contentStream.newLineAtOffset(headerX + 10, headerY + 10);
                contentStream.showText("Faktura");
                contentStream.endText();

                yPosition = headerY - lineHeight;

                // Bezeroaren datuak
                contentStream.setFont(PDType1Font.HELVETICA, 12);
                contentStream.beginText();
                contentStream.newLineAtOffset(50, yPosition);
                contentStream.showText("Bezeroa: " + izena + " " + abizena);
                contentStream.endText();
                yPosition -= lineHeight;

                contentStream.beginText();
                contentStream.newLineAtOffset(50, yPosition);
                contentStream.showText("Posta elektronikoa: " + postaElektronikoa);
                contentStream.endText();
                yPosition -= lineHeight;

                contentStream.beginText();
                contentStream.newLineAtOffset(50, yPosition);
                contentStream.showText("Erosketa Data: " + Eskaera_data);
                contentStream.endText();
                yPosition -= lineHeight * 2;

                // Produktuak
                contentStream.setFont(PDType1Font.HELVETICA_BOLD, 12);
                contentStream.beginText();
                contentStream.newLineAtOffset(50, yPosition);
                contentStream.showText("Produktua");
                contentStream.newLineAtOffset(350, 0);
                contentStream.showText("Kantitatea");
                contentStream.newLineAtOffset(80, 0);
                contentStream.showText("Subtotal (€)");
                contentStream.endText();
                yPosition -= lineHeight;

                contentStream.setFont(PDType1Font.HELVETICA, 12);
                for (ProductInfo p : productList) {
                    contentStream.beginText();
                    contentStream.newLineAtOffset(50, yPosition);
                    contentStream.showText(p.productName);
                    contentStream.newLineAtOffset(350, 0);
                    contentStream.showText(String.valueOf(p.quantity));
                    contentStream.newLineAtOffset(80, 0);
                    contentStream.showText(String.format("%.2f €", p.price));
                    contentStream.endText();
                    yPosition -= lineHeight;
                }

                // Prezio Totala
                yPosition -= lineHeight;
                contentStream.setFont(PDType1Font.HELVETICA_BOLD, 12);
                contentStream.beginText();
                contentStream.newLineAtOffset(50, yPosition);
                contentStream.showText("Guztira: " + String.format("%.2f €", guztira));
                contentStream.endText();

                contentStream.close();
                document.save(outputFile);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }

        return true;
    }

    // Produktuen informazioa gordetzeko laguntza klasea
    private static class ProductInfo {
        String productName;
        int quantity;
        double price;

        public ProductInfo(String productName, int quantity, double price) {
            this.productName = productName;
            this.quantity = quantity;
            this.price = price;
        }
    }
}
