package erronka3;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.util.Vector;

public class LangileakKontsultatuPanela extends JPanel {

    private static final long serialVersionUID = 1L;
    private JTextField txtFiltro;
    private JTable table;
    private JScrollPane scrollPane;

    public LangileakKontsultatuPanela() {
        setLayout(new BorderLayout());

        // Panel de cabecera
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(255, 165, 0)); // Naranja kolorea
        JLabel headerLabel = new JLabel("Langileak Kontsultatu");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 20));
        headerLabel.setForeground(Color.BLACK); // Letraren kolorea beltza
        headerPanel.add(headerLabel);

        // Panel de filtro
        JPanel filtroPanel = new JPanel();
        filtroPanel.setLayout(new FlowLayout());
        JLabel lblFiltro = new JLabel("Lanpostua Filtratu:");
        txtFiltro = new JTextField(15);
        JButton btnFiltrar = new JButton("Filtratu");
        btnFiltrar.addActionListener(e -> filtrarLangileak());

        filtroPanel.add(lblFiltro);
        filtroPanel.add(txtFiltro);
        filtroPanel.add(btnFiltrar);

        // Panel de tabla
        table = new JTable();
        scrollPane = new JScrollPane(table);
        table.setFillsViewportHeight(true);

        // Añadir paneles al panel principal
        add(headerPanel, BorderLayout.NORTH);
        add(filtroPanel, BorderLayout.CENTER);
        add(scrollPane, BorderLayout.SOUTH);
    }

    private void filtrarLangileak() {
        String filtro = txtFiltro.getText().trim();
        String sql = "SELECT ID, Izena, Abizena, Usuarioa, Posta_elektronikoa, Lanpostua FROM langileak";

        if (!filtro.isEmpty()) {
            sql += " WHERE Lanpostua LIKE ?";
        }

        try (Connection konexioa = DBKonexioa.lortuKonexioa();
             PreparedStatement pstmt = konexioa.prepareStatement(sql)) {

            if (!filtro.isEmpty()) {
                pstmt.setString(1, "%" + filtro + "%");
            }

            ResultSet rs = pstmt.executeQuery();
            table.setModel(buildTableModel(rs));

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Errorea gertatu da datuak lortzean.", "Errorea", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static TableModel buildTableModel(ResultSet rs) throws Exception {
        ResultSetMetaData metaData = rs.getMetaData();

        // Names of columns
        Vector<String> columnNames = new Vector<>();
        int columnCount = metaData.getColumnCount();
        for (int column = 1; column <= columnCount; column++) {
            columnNames.add(metaData.getColumnName(column));
        }

        // Data of the table
        Vector<Vector<Object>> data = new Vector<>();
        while (rs.next()) {
            Vector<Object> vector = new Vector<>();
            for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
                vector.add(rs.getObject(columnIndex));
            }
            data.add(vector);
        }

        return new DefaultTableModel(data, columnNames);
    }
}