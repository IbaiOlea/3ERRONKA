package erronka3;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TaulaKontrolatzailea {

    private JTable taula;
    private DBEkintzak Ekintzak;
    private TaulaPanela taulaPanela;
    private JPanel operazioPanela;

    public TaulaKontrolatzailea() {
        Ekintzak = new DBEkintzak();
    }

    private void taulaEguneratu(String taulaIzena) {
        taula = Kontsulta.lortuTaulenDatuak(taulaIzena);
        taulaPanela.ezarriTaula(taula);
        if (operazioPanela != null && operazioPanela.getComponentCount() > 0) {
            taulaPanela.gehituOperazioPanela(operazioPanela);
        }
    }

    public void kargatuTaula(String taulaIzena, TaulaPanela taulaPanela) {
        this.taulaPanela = taulaPanela;
        taula = Kontsulta.lortuTaulenDatuak(taulaIzena);
        taulaPanela.ezarriTaula(taula);

        operazioPanela = new JPanel(new FlowLayout());

        switch (taulaIzena) {
            case "erabiltzaileak":
            case "hornitzaileak":
                JButton btnEguneratu = new JButton("Erregistroa Eguneratu");
                btnEguneratu.setBackground(new Color(200, 200, 200));
                btnEguneratu.setForeground(Color.BLACK);
                btnEguneratu.addActionListener(e -> eguneratuErregistroa(taulaIzena));
                operazioPanela.add(btnEguneratu);

                JButton btnEzabatu = new JButton("Erregistroa Ezabatu");
                btnEzabatu.setBackground(new Color(200, 200, 200));
                btnEzabatu.setForeground(Color.BLACK);
                btnEzabatu.addActionListener(e -> ezabatuErregistroa(taulaIzena));
                operazioPanela.add(btnEzabatu);
                break;
            case "Fakturak":  
                JButton btnPDFDeskargatu = new JButton("PDF Deskargatu");
                btnPDFDeskargatu.setBackground(new Color(200, 200, 200));
                btnPDFDeskargatu.setForeground(Color.BLACK);
                btnPDFDeskargatu.addActionListener(e -> pdfDeskargatu());
                operazioPanela.add(btnPDFDeskargatu);
                break;
            case "langileak":
            case "produktuak":
                JButton btnGehitu = new JButton("Erregistroa Gehitu");
                btnGehitu.setBackground(new Color(200, 200, 200));
                btnGehitu.setForeground(Color.BLACK);
                btnGehitu.addActionListener(e -> gehituErregistroa(taulaIzena));
                operazioPanela.add(btnGehitu);

                JButton btnEguneratu2 = new JButton("Erregistroa Eguneratu");
                btnEguneratu2.setBackground(new Color(200, 200, 200));
                btnEguneratu2.setForeground(Color.BLACK);
                btnEguneratu2.addActionListener(e -> eguneratuErregistroa(taulaIzena));
                operazioPanela.add(btnEguneratu2);

                JButton btnEzabatu2 = new JButton("Erregistroa Ezabatu");
                btnEzabatu2.setBackground(new Color(200, 200, 200));
                btnEzabatu2.setForeground(Color.BLACK);
                btnEzabatu2.addActionListener(e -> ezabatuErregistroa(taulaIzena));
                operazioPanela.add(btnEzabatu2);
                break;
            default:
                break;
        }

        if (operazioPanela.getComponentCount() > 0) {
            taulaPanela.gehituOperazioPanela(operazioPanela);
        }
    }

    private void pdfDeskargatu() {
        JPanel panel = new JPanel(new GridLayout(2, 2, 5, 5));
        JLabel lblUser = new JLabel("ErabiltzaileID:");
        JComboBox<String> cmbUser = new JComboBox<>();
        JLabel lblDate = new JLabel("Erosketa_Data:");
        JComboBox<String> cmbDate = new JComboBox<>();

        try (Connection conn = DBKonexioa.lortuKonexioa();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT DISTINCT ErabiltzaileID FROM Fakturak")) {
            while (rs.next()) {
                cmbUser.addItem(rs.getString("ErabiltzaileID"));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Errorea erabiltzaileak kargatzerakoan: " + ex.getMessage());
            return;
        }

        cmbUser.addActionListener(e -> {
            cmbDate.removeAllItems();
            String selectedUser = (String) cmbUser.getSelectedItem();
            if (selectedUser != null) {
                try (Connection conn = DBKonexioa.lortuKonexioa();
                     PreparedStatement pstmt = conn.prepareStatement(
                             "SELECT DISTINCT Erosketa_Data FROM Fakturak WHERE ErabiltzaileID = ?")) {
                    pstmt.setString(1, selectedUser);
                    try (ResultSet rs = pstmt.executeQuery()) {
                        while (rs.next()) {
                            cmbDate.addItem(rs.getString("Erosketa_Data"));
                        }
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Errorea datak kargatzerakoan: " + ex.getMessage());
                }
            }
        });
        
        if (cmbUser.getItemCount() > 0) {
            cmbUser.setSelectedIndex(0);
        }

        panel.add(lblUser);
        panel.add(cmbUser);
        panel.add(lblDate);
        panel.add(cmbDate);

        int aukera = JOptionPane.showConfirmDialog(null, panel, "Eskaera aukeraketa", JOptionPane.OK_CANCEL_OPTION);
        if (aukera == JOptionPane.OK_OPTION) {
            String selectedUser = (String) cmbUser.getSelectedItem();
            String selectedDate = (String) cmbDate.getSelectedItem();
            
            if (selectedUser == null || selectedDate == null) {
                JOptionPane.showMessageDialog(null, "Erabiltzaile eta Erosketa_Data bat aukeratu behar dituzu!!!");
                return;
            }
            
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Faktura Sortu");
            int erabAukera = fileChooser.showSaveDialog(null);
            
            if (erabAukera == JFileChooser.APPROVE_OPTION) {
                File fileToSave = fileChooser.getSelectedFile();
                
                if (!fileToSave.getName().toLowerCase().endsWith(".pdf")) {
                    fileToSave = new File(fileToSave.getAbsolutePath() + ".pdf");
                }
                
                // Generar el PDF llamando al método corregido
                boolean arrakastatsua = PdfSortzailea.generatePDF(selectedUser, selectedDate, fileToSave);
                
                if (arrakastatsua) {
                    JOptionPane.showMessageDialog(null, "PDF-a ongi gorde da: " + fileToSave.getAbsolutePath());
                }
            }
        }
    }

    // Resto de métodos sin cambios...
    private void gehituErregistroa(String taulaIzena) { /* ... */ }
    private void eguneratuErregistroa(String taulaIzena) { /* ... */ }
    private void ezabatuErregistroa(String taulaIzena) { /* ... */ }
}