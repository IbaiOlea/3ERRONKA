package erronka3;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class LangileakEzabatuPanela extends JPanel {

    private static final long serialVersionUID = 1L;
    private JTextField txtId;

    public LangileakEzabatuPanela() {
        setLayout(new BorderLayout());

        // Panel de cabecera
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(255, 165, 0)); // Naranja kolorea
        JLabel headerLabel = new JLabel("Langileak Ezabatu");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 20));
        headerLabel.setForeground(Color.BLACK); // Letraren kolorea beltza
        headerPanel.add(headerLabel);

        // Panel de formulario
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(3, 2, 10, 10));

        formPanel.add(new JLabel("Langilearen ID:"));
        txtId = new JTextField(15);
        formPanel.add(txtId);

        JButton btnEzabatu = new JButton("Ezabatu");
        btnEzabatu.setBackground(new Color(0, 102, 204)); // Kolore urdina
        btnEzabatu.setForeground(Color.WHITE); // Testu kolorea zuria
        btnEzabatu.setFont(new Font("Arial", Font.BOLD, 14));
        btnEzabatu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ezabatuLangilea();
            }
        });

        formPanel.add(new JLabel());
        formPanel.add(btnEzabatu);

        // Añadir paneles al panel principal
        add(headerPanel, BorderLayout.NORTH);
        add(formPanel, BorderLayout.CENTER);
    }

    private void ezabatuLangilea() {
        String id = txtId.getText().trim();
        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Mesedez, sartu langilearen IDa.", "Errorea", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String sql = "DELETE FROM langileak WHERE ID = ?";

        try (Connection konexioa = DBKonexioa.lortuKonexioa();
             PreparedStatement pstmt = konexioa.prepareStatement(sql)) {

            pstmt.setString(1, id);

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                JOptionPane.showMessageDialog(this, "Langilea ezabatu da.", "Arrakasta", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Langilearen IDa ez da aurkitu.", "Errorea", JOptionPane.ERROR_MESSAGE);
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Errorea gertatu da langilea ezabatzean.", "Errorea", JOptionPane.ERROR_MESSAGE);
        }
    }
}