package erronka3;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ImcKalkulagailuPanela extends JPanel {
    private JTextField pisuaField;
    private JTextField altueraField;
    private JLabel emaitzaLabel;

    public ImcKalkulagailuPanela() {
        setLayout(new BorderLayout());

        // Datu sarrera panela
        JPanel inputPanel = new JPanel(new GridLayout(3, 2));
        inputPanel.add(new JLabel("Pisua (kg):"));
        pisuaField = new JTextField();
        inputPanel.add(pisuaField);
        inputPanel.add(new JLabel("Altuera (m):"));
        altueraField = new JTextField();
        inputPanel.add(altueraField);

        JButton kalkulatuButton = new JButton("IMC Kalkulatu");
        kalkulatuButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                kalkulatuIMC();
            }
        });
        
        inputPanel.add(kalkulatuButton);
        add(inputPanel, BorderLayout.CENTER);

        // Emaitza panela
        emaitzaLabel = new JLabel("Sartu zure pisua eta altuera IMC kalkulatzeko");
        add(emaitzaLabel, BorderLayout.SOUTH);
    }

    private void kalkulatuIMC() {
        try {
            double pisua = Double.parseDouble(pisuaField.getText());
            double altuera = Double.parseDouble(altueraField.getText());
            double imc = ImcKalkulagailua.calcularIMC(pisua, altuera);
            String egoera = ImcKalkulagailua.obtenerEstadoIMC(imc);
            emaitzaLabel.setText(String.format("IMC: %.2f - %s", imc, egoera));
        } catch (NumberFormatException e) {
            emaitzaLabel.setText("Mesedez, sartu balio zuzenak.");
        }
    }
}